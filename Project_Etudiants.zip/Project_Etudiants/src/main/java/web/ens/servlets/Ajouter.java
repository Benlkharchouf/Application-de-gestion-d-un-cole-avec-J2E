package web.ens.servlets;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/Ajouter")
public class Ajouter extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		 HttpSession session = request.getSession();
		 if(session.getAttribute("login") != null) {
			 String nom = request.getParameter("nom");
			 String prenom = request.getParameter("prenom");
			 String CNE = request.getParameter("CNE");
			 String tele = request.getParameter("tele");
			 String date = request.getParameter("date");
			 String sexe = request.getParameter("sexe");
			 String filiere = request.getParameter("filiere");
			 String depart = request.getParameter("depart");
				String url = "jdbc:mysql://localhost:3306/etudiant";
				String user ="root";
				String pwd="";
				try {
					Class.forName("com.mysql.jdbc.Driver");
					Connection con = DriverManager.getConnection(url, user, pwd);
					PreparedStatement pst = con.prepareStatement("INSERT INTO etudiants (nom,prenom,CNE,tele,date_inscr,sexe,filiere,depart) VALUES(?,?,?,?,?,?,?,?)");
					pst.setString(1, nom);
					pst.setString(2, prenom);
					pst.setString(3, CNE);
					pst.setString(4, tele);
					pst.setString(5, date);
					pst.setString(6, sexe);
					pst.setString(7, filiere);
					pst.setString(8, depart);
					pst.executeUpdate();
					response.sendRedirect("index.jsp");
					pst.close();
					con.close();			
				}catch (Exception e) {
					System.out.print(e);		
				}
 		 }else  response.sendRedirect("auth.jsp");
	}

}
